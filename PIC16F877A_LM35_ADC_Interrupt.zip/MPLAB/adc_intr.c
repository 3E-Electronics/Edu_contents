#include<pic.h>
#include<stdio.h>
//*********** Delay Function ***********//
void delay(unsigned int x)
{
	while(x--);
}

//********** Command Function *********//
void cmd(char c)
{
	RC0=0;
	RC1=1;
	delay(100);
	PORTB=c;
	delay(200);
	RC1=0;
	delay(200);
}

//********** Data Function *********//
void data(char c)
{
	RC0=1;
	RC1=1;
	delay(200);
	PORTB=c;
	delay(200);
	RC1=0;
	delay(200);
}

//********** String Function *********//
char* r = "Running...!";
char* s = "Over Heated..!";
char* c = "RESET the System";

//********** Reset Function *********//
void reset_fn()
{
	PORTC=0x00;
	PORTB=0x00;
	PORTD=0x00;
}

//********** String Display Section *********//

void intr_disp()
{
	cmd(0x01);
	delay(200);
	RC0=1;
	while(*s !='\0')
	{
		RC1=1;
		delay(200);
		PORTB=*s;
		s++;
		delay(200);
		RC1=0;
		delay(100);
	}
	cmd(0xc0);
	delay(200);
	RC0=1;
	while(*c !='\0')
	{
		RC1=1;
		delay(100);
		PORTB = *c;
		delay(100);
		c++;
		delay(100);
		RC1=0;
		delay(100);

	}
	reset_fn();
	while(1);
}


void disp_norm()
{
	RC0=1;
	delay(200);
	while(*r !='\0')
	{
		RC1=1;
		delay(200);
		PORTB=*r;
		r++;
		delay(200);
		RC1=0;
		delay(100);
	}
}


//********** LCD Init Function *********//
void lcd_init()
{
	TRISB = 0x00;
	PORTB = 0x00;
	TRISC0 = 0;
	TRISC1 = 0;
	RC0 = 0;
	RC1 = 0;
	cmd(0x0c);
	cmd(0x06);
	cmd(0x38);
	cmd(0x01);
	cmd(0x80);
}

//********** ADC Init Function *********//
void adc_init()
{
	TRISA = 0xff;
	ADCON0 = 0x81;
	ADCON1 = 0x40;
	ADRESH = 0x00;
	ADRESL = 0X00;
}

//********** USART_Init Function *********//
void usart_init()
{
	TRISC6 = 0;
	TRISC7 = 1;
	TXSTA=0x24;		// TX Reg
	RCSTA=0x90;		//RX Reg
	SPBRG=129;		// BPS set
	delay(100);
}

//********** Seven Seg Init Function *********//
void seven_seg()
{
	TRISD=0x00;
	PORTC=0x00;
}

//********** Main Function *********//
void main()
{
	lcd_init();
//	usart_init();
	seven_seg();
	int a[10]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0xff,0x6f};
	
	ADIF=0;
	ADIE=1;
	GIE=1;
	PEIE=1;

	adc_init();

	delay(100);
	disp_norm();
	delay(65000);
	delay(1000);
	GO=1;
	while(1)
	{
	for(int i=0;i<=9;i++)
		{
	  		PORTD=a[i];
	  		delay(500);
	 	}
	}	
}

int adc_read()
{
	int a = ADRESL, b = ADRESH;
	b =(b<<2)+(a>>6);			// shifting opt is done for placing the adc value in correct position
	ADRESH=0x00;
	ADRESL=0x00;
	return b;
}
	
unsigned int adc_val=0;
float temp=0.0;
char buf[10]={0,0,0,0,0,0,0,0,0,0};
int temp_val=0;
void interrupt adconversion()
{
	if(ADIF)
	{
		adc_val = adc_read();
		temp = adc_val*(500.0/1023.0);
		sprintf(buf,"%.2f",temp);
		temp_val = buf[0]+buf[1];
		if(temp>=40)
			intr_disp();
		GO=1;
		ADIF=0;
	//	}
	}
}